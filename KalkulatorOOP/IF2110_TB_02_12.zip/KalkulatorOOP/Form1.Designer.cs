﻿namespace KalkulatorOOP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.buttonSD = new System.Windows.Forms.Button();
            this.buttonT = new System.Windows.Forms.Button();
            this.buttonPLUS = new System.Windows.Forms.Button();
            this.buttonMINUS = new System.Windows.Forms.Button();
            this.buttonMulti = new System.Windows.Forms.Button();
            this.buttonBAGI = new System.Windows.Forms.Button();
            this.buttonAkar = new System.Windows.Forms.Button();
            this.buttonAns = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.buttonMR = new System.Windows.Forms.Button();
            this.buttonCLEAR = new System.Windows.Forms.Button();
            this.buttonBK = new System.Windows.Forms.Button();
            this.buttonTK = new System.Windows.Forms.Button();
            this.buttonSin = new System.Windows.Forms.Button();
            this.buttonCos = new System.Windows.Forms.Button();
            this.buttonTan = new System.Windows.Forms.Button();
            this.buttonPangkat = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.errorbox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox.BackColor = System.Drawing.SystemColors.MenuText;
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.textBox.ForeColor = System.Drawing.SystemColors.Info;
            this.textBox.Location = new System.Drawing.Point(128, 123);
            this.textBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.Size = new System.Drawing.Size(664, 68);
            this.textBox.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button1.Location = new System.Drawing.Point(322, 360);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 55);
            this.button1.TabIndex = 1;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button2.Location = new System.Drawing.Point(422, 360);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 55);
            this.button2.TabIndex = 2;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button3.Location = new System.Drawing.Point(522, 360);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 55);
            this.button3.TabIndex = 3;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button4.Location = new System.Drawing.Point(322, 295);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 55);
            this.button4.TabIndex = 4;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button5.Location = new System.Drawing.Point(422, 295);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 55);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button6.Location = new System.Drawing.Point(522, 295);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 55);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button7.Location = new System.Drawing.Point(322, 230);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 55);
            this.button7.TabIndex = 7;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button8.Location = new System.Drawing.Point(422, 230);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 55);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button9.Location = new System.Drawing.Point(522, 230);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 55);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button0.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.button0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.button0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button0.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.button0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.button0.Location = new System.Drawing.Point(422, 425);
            this.button0.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(75, 55);
            this.button0.TabIndex = 10;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = false;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // buttonSD
            // 
            this.buttonSD.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonSD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSD.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonSD.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonSD.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonSD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSD.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonSD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonSD.Location = new System.Drawing.Point(632, 360);
            this.buttonSD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonSD.Name = "buttonSD";
            this.buttonSD.Size = new System.Drawing.Size(75, 120);
            this.buttonSD.TabIndex = 11;
            this.buttonSD.Text = "=";
            this.buttonSD.UseVisualStyleBackColor = false;
            this.buttonSD.Click += new System.EventHandler(this.buttonSD_Click);
            // 
            // buttonT
            // 
            this.buttonT.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonT.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.buttonT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonT.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.buttonT.Location = new System.Drawing.Point(522, 425);
            this.buttonT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonT.Name = "buttonT";
            this.buttonT.Size = new System.Drawing.Size(75, 55);
            this.buttonT.TabIndex = 12;
            this.buttonT.Text = ".";
            this.buttonT.UseVisualStyleBackColor = false;
            this.buttonT.Click += new System.EventHandler(this.buttonT_Click);
            // 
            // buttonPLUS
            // 
            this.buttonPLUS.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonPLUS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPLUS.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonPLUS.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonPLUS.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonPLUS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPLUS.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonPLUS.ForeColor = System.Drawing.Color.HotPink;
            this.buttonPLUS.Location = new System.Drawing.Point(717, 360);
            this.buttonPLUS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPLUS.Name = "buttonPLUS";
            this.buttonPLUS.Size = new System.Drawing.Size(75, 55);
            this.buttonPLUS.TabIndex = 13;
            this.buttonPLUS.Text = "+";
            this.buttonPLUS.UseVisualStyleBackColor = false;
            this.buttonPLUS.Click += new System.EventHandler(this.buttonPLUS_Click);
            // 
            // buttonMINUS
            // 
            this.buttonMINUS.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonMINUS.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMINUS.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonMINUS.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonMINUS.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonMINUS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMINUS.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonMINUS.ForeColor = System.Drawing.Color.HotPink;
            this.buttonMINUS.Location = new System.Drawing.Point(717, 425);
            this.buttonMINUS.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMINUS.Name = "buttonMINUS";
            this.buttonMINUS.Size = new System.Drawing.Size(75, 55);
            this.buttonMINUS.TabIndex = 14;
            this.buttonMINUS.Text = "-";
            this.buttonMINUS.UseVisualStyleBackColor = false;
            this.buttonMINUS.Click += new System.EventHandler(this.buttonMINUS_Click);
            // 
            // buttonMulti
            // 
            this.buttonMulti.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonMulti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMulti.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonMulti.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonMulti.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonMulti.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMulti.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonMulti.ForeColor = System.Drawing.Color.HotPink;
            this.buttonMulti.Location = new System.Drawing.Point(632, 295);
            this.buttonMulti.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMulti.Name = "buttonMulti";
            this.buttonMulti.Size = new System.Drawing.Size(75, 55);
            this.buttonMulti.TabIndex = 15;
            this.buttonMulti.Text = "*";
            this.buttonMulti.UseVisualStyleBackColor = false;
            this.buttonMulti.Click += new System.EventHandler(this.buttonMulti_Click);
            // 
            // buttonBAGI
            // 
            this.buttonBAGI.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonBAGI.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBAGI.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonBAGI.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonBAGI.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonBAGI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBAGI.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonBAGI.ForeColor = System.Drawing.Color.HotPink;
            this.buttonBAGI.Location = new System.Drawing.Point(717, 295);
            this.buttonBAGI.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBAGI.Name = "buttonBAGI";
            this.buttonBAGI.Size = new System.Drawing.Size(75, 55);
            this.buttonBAGI.TabIndex = 16;
            this.buttonBAGI.Text = "/";
            this.buttonBAGI.UseVisualStyleBackColor = false;
            this.buttonBAGI.Click += new System.EventHandler(this.buttonBAGI_Click);
            // 
            // buttonAkar
            // 
            this.buttonAkar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonAkar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAkar.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonAkar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonAkar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonAkar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAkar.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonAkar.ForeColor = System.Drawing.Color.HotPink;
            this.buttonAkar.Location = new System.Drawing.Point(213, 295);
            this.buttonAkar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAkar.Name = "buttonAkar";
            this.buttonAkar.Size = new System.Drawing.Size(75, 55);
            this.buttonAkar.TabIndex = 17;
            this.buttonAkar.Text = "√";
            this.buttonAkar.UseVisualStyleBackColor = true;
            this.buttonAkar.Click += new System.EventHandler(this.buttonAkar_Click);
            // 
            // buttonAns
            // 
            this.buttonAns.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonAns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAns.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrange;
            this.buttonAns.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonAns.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonAns.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAns.Font = new System.Drawing.Font("VCR OSD Mono", 11F, System.Drawing.FontStyle.Bold);
            this.buttonAns.ForeColor = System.Drawing.Color.Red;
            this.buttonAns.Location = new System.Drawing.Point(213, 230);
            this.buttonAns.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAns.Name = "buttonAns";
            this.buttonAns.Size = new System.Drawing.Size(75, 55);
            this.buttonAns.TabIndex = 18;
            this.buttonAns.Text = "Ans";
            this.buttonAns.UseVisualStyleBackColor = false;
            this.buttonAns.Click += new System.EventHandler(this.buttonAns_Click);
            // 
            // buttonMC
            // 
            this.buttonMC.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonMC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMC.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.buttonMC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonMC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonMC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMC.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonMC.ForeColor = System.Drawing.Color.LemonChiffon;
            this.buttonMC.Location = new System.Drawing.Point(127, 230);
            this.buttonMC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(75, 55);
            this.buttonMC.TabIndex = 19;
            this.buttonMC.Text = "MC";
            this.buttonMC.UseVisualStyleBackColor = false;
            this.buttonMC.Click += new System.EventHandler(this.buttonMC_Click);
            // 
            // buttonMR
            // 
            this.buttonMR.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonMR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonMR.FlatAppearance.BorderColor = System.Drawing.Color.Gold;
            this.buttonMR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonMR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonMR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMR.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonMR.ForeColor = System.Drawing.Color.LemonChiffon;
            this.buttonMR.Location = new System.Drawing.Point(127, 295);
            this.buttonMR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonMR.Name = "buttonMR";
            this.buttonMR.Size = new System.Drawing.Size(75, 55);
            this.buttonMR.TabIndex = 20;
            this.buttonMR.Text = "MR";
            this.buttonMR.UseVisualStyleBackColor = false;
            this.buttonMR.Click += new System.EventHandler(this.buttonMR_Click);
            // 
            // buttonCLEAR
            // 
            this.buttonCLEAR.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonCLEAR.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCLEAR.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrange;
            this.buttonCLEAR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonCLEAR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonCLEAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCLEAR.Font = new System.Drawing.Font("VCR OSD Mono", 11F, System.Drawing.FontStyle.Bold);
            this.buttonCLEAR.ForeColor = System.Drawing.Color.Red;
            this.buttonCLEAR.Location = new System.Drawing.Point(322, 425);
            this.buttonCLEAR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonCLEAR.Name = "buttonCLEAR";
            this.buttonCLEAR.Size = new System.Drawing.Size(75, 55);
            this.buttonCLEAR.TabIndex = 21;
            this.buttonCLEAR.Text = "C";
            this.buttonCLEAR.UseVisualStyleBackColor = false;
            this.buttonCLEAR.Click += new System.EventHandler(this.buttonCLEAR_Click);
            // 
            // buttonBK
            // 
            this.buttonBK.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonBK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBK.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonBK.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonBK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonBK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBK.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonBK.ForeColor = System.Drawing.Color.HotPink;
            this.buttonBK.Location = new System.Drawing.Point(632, 230);
            this.buttonBK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonBK.Name = "buttonBK";
            this.buttonBK.Size = new System.Drawing.Size(75, 55);
            this.buttonBK.TabIndex = 22;
            this.buttonBK.Text = "(";
            this.buttonBK.UseVisualStyleBackColor = true;
            this.buttonBK.Click += new System.EventHandler(this.buttonBK_Click);
            // 
            // buttonTK
            // 
            this.buttonTK.BackColor = System.Drawing.SystemColors.ControlText;
            this.buttonTK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTK.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonTK.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonTK.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonTK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTK.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonTK.ForeColor = System.Drawing.Color.HotPink;
            this.buttonTK.Location = new System.Drawing.Point(717, 230);
            this.buttonTK.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonTK.Name = "buttonTK";
            this.buttonTK.Size = new System.Drawing.Size(75, 55);
            this.buttonTK.TabIndex = 23;
            this.buttonTK.Text = ")";
            this.buttonTK.UseVisualStyleBackColor = false;
            this.buttonTK.Click += new System.EventHandler(this.buttonTK_Click);
            // 
            // buttonSin
            // 
            this.buttonSin.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonSin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSin.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonSin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonSin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonSin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSin.Font = new System.Drawing.Font("VCR OSD Mono", 11F, System.Drawing.FontStyle.Bold);
            this.buttonSin.ForeColor = System.Drawing.Color.HotPink;
            this.buttonSin.Location = new System.Drawing.Point(127, 360);
            this.buttonSin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonSin.Name = "buttonSin";
            this.buttonSin.Size = new System.Drawing.Size(75, 55);
            this.buttonSin.TabIndex = 24;
            this.buttonSin.Text = "sin";
            this.buttonSin.UseVisualStyleBackColor = true;
            this.buttonSin.Click += new System.EventHandler(this.buttonSin_Click);
            // 
            // buttonCos
            // 
            this.buttonCos.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonCos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonCos.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonCos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonCos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonCos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCos.Font = new System.Drawing.Font("VCR OSD Mono", 11F, System.Drawing.FontStyle.Bold);
            this.buttonCos.ForeColor = System.Drawing.Color.HotPink;
            this.buttonCos.Location = new System.Drawing.Point(127, 425);
            this.buttonCos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonCos.Name = "buttonCos";
            this.buttonCos.Size = new System.Drawing.Size(75, 55);
            this.buttonCos.TabIndex = 25;
            this.buttonCos.Text = "cos";
            this.buttonCos.UseVisualStyleBackColor = true;
            this.buttonCos.Click += new System.EventHandler(this.buttonCos_Click);
            // 
            // buttonTan
            // 
            this.buttonTan.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonTan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTan.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonTan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonTan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonTan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTan.Font = new System.Drawing.Font("VCR OSD Mono", 11F, System.Drawing.FontStyle.Bold);
            this.buttonTan.ForeColor = System.Drawing.Color.HotPink;
            this.buttonTan.Location = new System.Drawing.Point(213, 425);
            this.buttonTan.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonTan.Name = "buttonTan";
            this.buttonTan.Size = new System.Drawing.Size(75, 55);
            this.buttonTan.TabIndex = 26;
            this.buttonTan.Text = "tan";
            this.buttonTan.UseVisualStyleBackColor = false;
            this.buttonTan.Click += new System.EventHandler(this.buttonTan_Click);
            // 
            // buttonPangkat
            // 
            this.buttonPangkat.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonPangkat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonPangkat.FlatAppearance.BorderColor = System.Drawing.Color.DeepPink;
            this.buttonPangkat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SteelBlue;
            this.buttonPangkat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkBlue;
            this.buttonPangkat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPangkat.Font = new System.Drawing.Font("VCR OSD Mono", 15F, System.Drawing.FontStyle.Bold);
            this.buttonPangkat.ForeColor = System.Drawing.Color.HotPink;
            this.buttonPangkat.Location = new System.Drawing.Point(213, 360);
            this.buttonPangkat.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonPangkat.Name = "buttonPangkat";
            this.buttonPangkat.Size = new System.Drawing.Size(75, 55);
            this.buttonPangkat.TabIndex = 27;
            this.buttonPangkat.Text = "^";
            this.buttonPangkat.UseVisualStyleBackColor = false;
            this.buttonPangkat.Click += new System.EventHandler(this.buttonPangkat_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.buttonClose.Location = new System.Drawing.Point(876, 6);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(42, 34);
            this.buttonClose.TabIndex = 28;
            this.buttonClose.Text = "X";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(14, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 20);
            this.label1.TabIndex = 29;
            this.label1.Text = "Kalkulator";
            // 
            // errorbox
            // 
            this.errorbox.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.errorbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.errorbox.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.errorbox.ForeColor = System.Drawing.SystemColors.InactiveCaption;
            this.errorbox.Location = new System.Drawing.Point(18, 588);
            this.errorbox.Name = "errorbox";
            this.errorbox.ReadOnly = true;
            this.errorbox.Size = new System.Drawing.Size(495, 19);
            this.errorbox.TabIndex = 30;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.label2.Location = new System.Drawing.Point(14, 549);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "Error:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(918, 619);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.errorbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.buttonPangkat);
            this.Controls.Add(this.buttonTan);
            this.Controls.Add(this.buttonCos);
            this.Controls.Add(this.buttonSin);
            this.Controls.Add(this.buttonTK);
            this.Controls.Add(this.buttonBK);
            this.Controls.Add(this.buttonCLEAR);
            this.Controls.Add(this.buttonMR);
            this.Controls.Add(this.buttonMC);
            this.Controls.Add(this.buttonAns);
            this.Controls.Add(this.buttonAkar);
            this.Controls.Add(this.buttonBAGI);
            this.Controls.Add(this.buttonMulti);
            this.Controls.Add(this.buttonMINUS);
            this.Controls.Add(this.buttonPLUS);
            this.Controls.Add(this.buttonT);
            this.Controls.Add(this.buttonSD);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(918, 619);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(918, 619);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kalkulator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button buttonSD;
        private System.Windows.Forms.Button buttonT;
        private System.Windows.Forms.Button buttonPLUS;
        private System.Windows.Forms.Button buttonMINUS;
        private System.Windows.Forms.Button buttonMulti;
        private System.Windows.Forms.Button buttonBAGI;
        private System.Windows.Forms.Button buttonAkar;
        private System.Windows.Forms.Button buttonAns;
        private System.Windows.Forms.Button buttonMC;
        private System.Windows.Forms.Button buttonMR;
        private System.Windows.Forms.Button buttonCLEAR;
        private System.Windows.Forms.Button buttonBK;
        private System.Windows.Forms.Button buttonTK;
        private System.Windows.Forms.Button buttonSin;
        private System.Windows.Forms.Button buttonCos;
        private System.Windows.Forms.Button buttonTan;
        private System.Windows.Forms.Button buttonPangkat;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox errorbox;
        private System.Windows.Forms.Label label2;
    }
}

